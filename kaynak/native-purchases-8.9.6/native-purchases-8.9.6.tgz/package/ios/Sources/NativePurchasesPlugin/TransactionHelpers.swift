import Foundation
import StoreKit

internal class TransactionHelpers {

    static func buildTransactionResponse(
        from transaction: Transaction,
        jwsRepresentation: String? = nil,
        alwaysIncludeWillCancel: Bool = false
    ) async -> [String: Any] {
        var response: [String: Any] = ["transactionId": String(transaction.id)]

        if alwaysIncludeWillCancel {
            response["willCancel"] = NSNull()
        }

        addReceiptAndJws(to: &response, jws: jwsRepresentation)
        addTransactionDetails(to: &response, transaction: transaction)

        if transaction.productType == .autoRenewable {
            addSubscriptionInfo(to: &response, transaction: transaction)
            await addRenewalInfo(to: &response, transaction: transaction)
        }

        return response
    }

    private static func addReceiptAndJws(to response: inout [String: Any], jws: String?) {
        if let receiptBase64 = getReceiptData() {
            response["receipt"] = receiptBase64
        }
        if let jws = jws {
            response["jwsRepresentation"] = jws
        }
    }

    private static func addTransactionDetails(to response: inout [String: Any], transaction: Transaction) {
        response["productIdentifier"] = transaction.productID
        response["purchaseDate"] = ISO8601DateFormatter().string(from: transaction.purchaseDate)
        response["productType"] = transaction.productType == .autoRenewable ? "subs" : "inapp"
        response["isUpgraded"] = transaction.isUpgraded
        response["ownershipType"] = transaction.ownershipType.descriptionString

        if let revocationDate = transaction.revocationDate {
            response["revocationDate"] = ISO8601DateFormatter().string(from: revocationDate)
        }
        if let revocationReason = transaction.revocationReason {
            response["revocationReason"] = revocationReason.descriptionString
        }
        if #available(iOS 17.0, *) {
            response["transactionReason"] = transaction.reason.descriptionString
        }
        if #available(iOS 16.0, *) {
            response["environment"] = transaction.environment.descriptionString
        }
        if let token = transaction.appAccountToken {
            response["appAccountToken"] = token.uuidString
        }

        addStoreKitJSONDetails(to: &response, transaction: transaction)
    }

    private static func addStoreKitJSONDetails(to response: inout [String: Any], transaction: Transaction) {
        if let transactionJSON = StoreKitPayloadHelpers.jsonDictionary(from: transaction.jsonRepresentation) {
            if let billingPlanType = StoreKitPayloadHelpers.normalizedBillingPlanType(
                from: transactionJSON["billingPlanType"]
            ) {
                response["billingPlanType"] = billingPlanType
            }
            if let commitmentInfo = StoreKitPayloadHelpers.transactionCommitmentInfo(
                from: transactionJSON["commitmentInfo"]
            ) {
                response["commitmentInfo"] = commitmentInfo
            }
            if let currency = transactionJSON["currency"] as? String {
                response["currencyCode"] = currency
            }
        }

        #if STOREKIT_26_5
        if #available(iOS 26.4, *) {
            if let billingPlanType = transaction.billingPlanType {
                response["billingPlanType"] = billingPlanType.capacitorString
            }
            if let commitmentInfo = transaction.commitmentInfo {
                response["commitmentInfo"] = commitmentInfo.dictionary
            }
        }
        #endif
    }

    static func getReceiptData() -> String? {
        guard let appStoreReceiptURL = Bundle.main.appStoreReceiptURL,
              FileManager.default.fileExists(atPath: appStoreReceiptURL.path),
              let receiptData = try? Data(contentsOf: appStoreReceiptURL) else {
            return nil
        }
        return receiptData.base64EncodedString()
    }

    static func addSubscriptionInfo(to response: inout [String: Any], transaction: Transaction) {
        response["originalPurchaseDate"] = ISO8601DateFormatter().string(
            from: transaction.originalPurchaseDate
        )
        if let expirationDate = transaction.expirationDate {
            response["expirationDate"] = ISO8601DateFormatter().string(from: expirationDate)
            response["isActive"] = expirationDate > Date()
        }
    }

    static func addRenewalInfo(to response: inout [String: Any], transaction: Transaction) async {
        guard let subscriptionStatus = await transaction.subscriptionStatus else {
            response["willCancel"] = NSNull()
            return
        }

        response["subscriptionState"] = subscriptionStatus.state.descriptionString

        if subscriptionStatus.state == .subscribed {
            if case .verified(let value) = subscriptionStatus.renewalInfo {
                response["willCancel"] = !value.willAutoRenew
                response["renewalInfo"] = renewalInfoDictionary(from: value)
            } else {
                response["willCancel"] = NSNull()
            }
        } else {
            response["willCancel"] = NSNull()
        }
    }

    private static func renewalInfoDictionary(
        from renewalInfo: Product.SubscriptionInfo.RenewalInfo
    ) -> [String: Any] {
        let renewalJSON = StoreKitPayloadHelpers.jsonDictionary(from: renewalInfo.jsonRepresentation)
        var dictionary = StoreKitPayloadHelpers.renewalInfo(
            from: renewalJSON,
            fallbackWillAutoRenew: renewalInfo.willAutoRenew
        ) ?? ["willAutoRenew": renewalInfo.willAutoRenew]

        #if STOREKIT_26_5
        if #available(iOS 26.4, *), let commitmentInfo = renewalInfo.commitmentInfo {
            dictionary["commitmentInfo"] = commitmentInfo.dictionary
        }
        #endif

        return dictionary
    }

    static func collectUnfinishedTransactions() async throws -> [[String: Any]] {
        var unfinished: [[String: Any]] = []
        for await result in Transaction.unfinished {
            guard case .verified(let transaction) = result else { continue }
            var payload = await buildTransactionResponse(
                from: transaction,
                jwsRepresentation: result.jwsRepresentation,
                alwaysIncludeWillCancel: true
            )
            payload["needsFinish"] = true
            unfinished.append(payload)
        }
        return unfinished
    }

    static func collectAllPurchases(appAccountTokenFilter: String?, onlyCurrentEntitlements: Bool = false) async throws -> [[String: Any]] {
        var allPurchases: [[String: Any]] = []
        if onlyCurrentEntitlements {
            try await collectPurchases(from: Transaction.currentEntitlements, filter: appAccountTokenFilter, into: &allPurchases)
        } else {
            try await collectPurchases(from: Transaction.all, filter: appAccountTokenFilter, into: &allPurchases)
        }
        return allPurchases
    }

    private static func collectPurchases<S: AsyncSequence>(
        from source: S,
        filter appAccountTokenFilter: String?,
        into allPurchases: inout [[String: Any]]
    ) async throws where S.Element == VerificationResult<Transaction> {
        for try await result in source {
            guard case .verified(let transaction) = result else { continue }
            if let filter = appAccountTokenFilter,
               transaction.appAccountToken?.uuidString != filter { continue }
            let data = await buildTransactionResponse(
                from: transaction,
                jwsRepresentation: result.jwsRepresentation
            )
            allPurchases.append(data)
        }
    }
}

private extension Transaction.RevocationReason {
    var descriptionString: String {
        switch self {
        case .developerIssue: return "developerIssue"
        case .other: return "other"
        default: return "unknown"
        }
    }
}

@available(iOS 17.0, *)
private extension Transaction.Reason {
    var descriptionString: String {
        switch self {
        case .purchase: return "purchase"
        case .renewal: return "renewal"
        default: return "unknown"
        }
    }
}

private extension Transaction.OwnershipType {
    var descriptionString: String {
        switch self {
        case .purchased: return "purchased"
        case .familyShared: return "familyShared"
        default: return "purchased"
        }
    }
}

@available(iOS 16.0, *)
private extension AppStore.Environment {
    var descriptionString: String {
        switch self {
        case .sandbox: return "Sandbox"
        case .production: return "Production"
        case .xcode: return "Xcode"
        default: return "Production"
        }
    }
}

private extension Product.SubscriptionInfo.RenewalState {
    var descriptionString: String {
        switch self {
        case .subscribed: return "subscribed"
        case .expired: return "expired"
        case .revoked: return "revoked"
        case .inGracePeriod: return "inGracePeriod"
        case .inBillingRetryPeriod: return "inBillingRetryPeriod"
        default: return "unknown"
        }
    }
}
